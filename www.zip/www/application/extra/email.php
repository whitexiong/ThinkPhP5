
<?php
/**
 * 发送邮箱相关配置
 */
return [
	//端口号
	'Port' => 25,
	//SMTP地址
	'Host' => 'smtp.126.com',
	//发送人邮箱
	'Username' => 'whitexxx@126.com',
	//授权密码(不是邮箱密码)
	'Password' => 'a17782285981',
	//发送人姓名
	'SendName' => 'PetFamily',
	//接收方
	'To'	=>  '986247535@qq.com',
	//接收方姓名
	'ToName' => 'xb',
	//发送主题
	'Subject' => 'Hello petFamily',
	//发送内容
	'Msg'	=> 'test',


];