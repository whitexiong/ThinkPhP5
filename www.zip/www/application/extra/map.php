<?php
return [
    'ak' => 'dFSvgI4WdprGsBM3OoA7TkoTZrkAgak2',
    'baidu_map_url' => 'http://api.map.baidu.com/',
    'geocoder' => 'geocoder/v2/',
    'width' =>  500,
    'height' => 600,
    'staticimage' => 'staticimage/v2',
];

//http://api.map.baidu.com/staticimage/v2?ak=dFSvgI4WdprGsBM3OoA7TkoTZrkAgak2