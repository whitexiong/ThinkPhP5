﻿<?php
class Map
{
public static function getLngLat($address)
	{
		if(!$address){
			return '';
		}	
		// http://api.map.baidu.com/geocoder/v2/?address=北京市海淀区上地十街10号&output=json&ak=E4805d16520de693a3fe707cdc962045&callback=showLocation



		$data = [
			'address' => $address,
			'ak'	  => config('map.ak'),//获取配置文件中ak
			'output'  => 'json',
		];

		//转换http为JSON
		$url = config('map.baidu_map_url').config('map.geocoder').'?'.http_build_query($data);

	

			//调用公共类中的方法
			
			//	$result = doCurl($url);
			$result = file_get_contents($url);
			if($result){
				return json_decode($result,true);
			}else{
				return [];
			}

			

	}
	


	public static function staticimage($center)
	{
		$data = [
			'ak'	  => (string)'dFSvgI4WdprGsBM3OoA7TkoTZrkAgak2',//获取配置文件中ak
			'width' => (int)300,
			'height' => (int)400,
			'center' => $center,
			'markers' => $center,
		];

		//转换http为JSON
		//
		//print_r($data);
		$url = config('map.baidu_map_url').config('map.staticimage').'?'.http_build_query($data);

		
		//print_r($url);
			//调用公共类中的方法
			$result = doCurl($url);
			$ary [] =  "ASCII" ;
			$ary [] =  "JIS" ;
			$ary [] =  "EUC-JP" ;
			$ary [] =  "UTF-8" ;
			$encode = mb_detect_encoding($result, array("ASCII","GB2312","GBK","UTF-8"));
			if($encode == "CP936"){
				$str = iconv("CP936", "ISO-8859-1//IGNORE", $encode);
				if($str){
				   return dump($str)."PHP   ";
				}else{
					echo "转换失败";
				}
			}

			//dump(mb_detect_encoding ( $result ,  $ary ));
		
	}
	

  }



// http://api.map.baidu.com/staticimage/v2?ak=dFSvgI4WdprGsBM3OoA7TkoTZrkAgak2&mcode=666666&center=116.403874,39.914888&width=300&height=200&zoom=11    
// //请将AK替换为您的AK


//http://api.map.baidu.com/staticimage/v2?ak=RtwcyTxiL4meGcGivQ5b8Dse1GnEIq5P